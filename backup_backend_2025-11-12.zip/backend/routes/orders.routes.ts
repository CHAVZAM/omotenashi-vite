//backend/routes/orders.routes.ts

import { Router } from 'express';
import { createOrder } from '../controllers/orders.controller';
// 🚨 CORRECCIÓN CLAVE: Usamos 'import * as server' para garantizar que se cargue
import * as server from '../server'; 

const ordersRouter = Router();

// 🚨 USAMOS: server.upload para acceder a la propiedad.
ordersRouter.post('/create-order', server.upload.single('proofFile'), createOrder);

export default ordersRouter;
