// backend/server.ts
import dotenv from "dotenv";
import express, { Application, Request, Response, NextFunction } from "express";
import cors from "cors";
import multer, { FileFilterCallback } from "multer";
import path from "path";
import fs from "fs";

// 1. CARGA DE VARIABLES DE ENTORNO (Debe ir al inicio)
dotenv.config();

// 2. IMPORTACIONES CENTRALES
import db from "./db";

const app: Application = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3001;

// --- Middleware BASE ---
app.use(
  cors({
    origin: "http://localhost:5175",
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// =====================================================================
// --- CONFIGURACIÓN Y EXPORTACIÓN DE MULTER (CRÍTICO) ---
// Debe estar definido ANTES de que cualquier ruta lo intente importar.
// =====================================================================

// Ruta para guardar archivos (la carpeta "uploads" está en el root de tu proyecto)
// Usamos process.cwd() para estabilidad en tu Mac.
const uploadsDir = path.join(process.cwd(), "uploads");

// Crea la carpeta 'uploads' si no existe
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (
    req: Request,
    file: Express.Multer.File,
    cb: (error: Error | null, destination: string) => void
  ) {
    cb(null, uploadsDir);
  },
  filename: function (
    req: Request,
    file: Express.Multer.File,
    cb: (error: Error | null, filename: string) => void
  ) {
    // Nombre único: timestamp + nombre original codificado para seguridad
    cb(
      null,
      Date.now() +
        "-" +
        encodeURIComponent(file.originalname.replace(/\s/g, "_"))
    );
  },
});

// Filtro de archivos: Permite JPG, PNG, y PDF
const fileFilter = (
  req: Request,
  file: Express.Multer.File,
  cb: FileFilterCallback
) => {
  const allowedTypes = ["image/jpeg", "image/png", "application/pdf"];

  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(
      new Error(
        "Tipo de archivo no soportado. Solo se aceptan JPG, PNG, o PDF."
      )
    );
  }
};

// EXPORTACIÓN FINAL DEL MIDDLEWARE DE MULTER
export const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 1024 * 1024 * 5, // Límite de 5 MB
  },
});

// --- Sirve los archivos estáticos de la carpeta 'uploads' ---
app.use("/uploads", express.static(uploadsDir));

// --- Rutas BASE ---
app.get("/api/health", (req: Request, res: Response) => {
  res.json({ status: "Servidor Omotenashi funcionando correctamente 🧠✨" });
});

// 🚨 REORGANIZACIÓN CLAVE: IMPORTAR LAS RUTAS AQUÍ (DESPUÉS DE DEFINIR 'upload')
import apiRoutes from "./routes";
app.use("/api", apiRoutes);

// --- Manejo de errores global ---
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error(err.stack);

  // Manejo específico de errores de Multer
  if (err instanceof multer.MulterError) {
    return res.status(400).send({ message: `Error de subida: ${err.message}` });
  } else if (err.message.includes("Tipo de archivo no soportado")) {
    return res.status(400).send({ message: err.message });
  }

  res.status(500).send("Algo salió mal en el servidor!");
});

// --- Iniciar el Servidor ---
async function startServer() {
  try {
    const [rows] = await db.execute("SELECT 1 + 1 AS solution");
    console.log("Conexión a la base de datos MySQL establecida correctamente.");
    console.log("Prueba de conexión a DB:", (rows as any[])[0].solution);

    app.listen(PORT, () => {
      console.log(`Servidor backend corriendo en http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error(
      "Error al iniciar el servidor o conectar a la base de datos:",
      error
    );
    process.exit(1);
  }
}

startServer();
